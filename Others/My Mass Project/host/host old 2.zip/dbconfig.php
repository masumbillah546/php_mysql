<?php


	$host= "localhost";
	$user="id11953052_masumbillah546";
	$pass="M20121991a@M20121991a";
	$db="id11953052_masum";


	
	// $host= "localhost";
	// $user="root";
	// $pass="";
	// $db="mess";

	$con = mysqli_connect($host, $user, $pass, $db);


?>